//
//  WWMediumView.swift
//  WeatherForecastWidgetsExtension
//
//  Created by Chandresh Kachariya on 18/10/22.
//  Copyright © 2022 Muhammad Osama Naeem. All rights reserved.
//

import SwiftUI

struct WWMediumView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct WWMediumView_Previews: PreviewProvider {
    static var previews: some View {
        WWMediumView()
    }
}
